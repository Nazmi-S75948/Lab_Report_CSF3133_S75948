CREATE DATABASE Lab5;
USE LAB5;
CREATE TABLE itemcategory(
  iccode INT(4) PRIMARY KEY AUTO_INCREMENT,
  icdescription VARCHAR(100)
);
ALTER TABLE itemcategory AUTO_INCREMENT = 101;

CREATE TABLE Item (
  itmcode VARCHAR(20) PRIMARY KEY,
  itmdesc VARCHAR(100),
  iccode INT(4),
  avgmthlyusage DECIMAL(10,2),
  reorderlevel DECIMAL(10,2),
  reorderqty DECIMAL(10,2),
  FOREIGN KEY (iccode) REFERENCES itemcategory(iccode)
);

CREATE TABLE itemstock (
  itmcode VARCHAR(20) NOT NULL,
  stkcountdate DATE NOT NULL, 
  qtystock DECIMAL(10,2),
  stkcountstatus VARCHAR(10) CHECK (stkcountstatus IN ('Opened', 'Closed')),
  PRIMARY KEY (itmcode, stkcountdate),  
  FOREIGN KEY (itmcode) REFERENCES item(itmcode)
);


CREATE TABLE Supplier (
  suppid INT(6) PRIMARY KEY auto_increment,
  suppname VARCHAR(50),
  suppemail VARCHAR(20),
  suppofficeno VARCHAR(20),
  supphpno VARCHAR(20)
);
ALTER TABLE Supplier AUTO_INCREMENT = 300001;

CREATE TABLE itemsupplier (
  itmcode VARCHAR(20) NOT NULL,
  suppid INT(6) NOT NULL,
  totqtysupptodate DECIMAL(10,2),
  firstdatesupply DATE,
  lastdatesupply DATE,
  stdprice DECIMAL (10,2),
  discount DECIMAL(10,2),	
  minorderqty DECIMAL(10,2),
  maxorderqty DECIMAL(10,2),
  PRIMARY KEY (itmcode, suppid),
  FOREIGN KEY (itmcode) REFERENCES item(itmcode),
  FOREIGN KEY (suppid) REFERENCES supplier(suppid)
);

CREATE TABLE Supplieraddress(
  suppaddid INT(6) PRIMARY KEY AUTO_INCREMENT,
  suppid INT(6),
  addr1 VARCHAR(100),
  city VARCHAR(50),
  postcode VARCHAR(20),
  state VARCHAR(20),
  FOREIGN KEY (suppid) REFERENCES supplier(suppid)
);
ALTER TABLE Supplieraddress AUTO_INCREMENT = 2001;

INSERT INTO itemcategory (icdescription) VALUES
('Home Appliances'),
('Electronics'),
('Furniture'),
('Groceries'),
('Stationery');

INSERT INTO supplier (suppname, suppemail, suppofficeno, supphpno) VALUES
('Global Supply Sdn Bhd', 'global@gmail.com', '095551234', '0134567890'),
('Mega Trading', 'mega@gmail.com', '095559999', '0178887777'),
('ABC Wholesaler', 'abc@gmail.com', '095552222', '0193334444'),
('Top Distributor', 'top@gmail.com', '095557777', '0129988776'),
('UniCart Supplier', 'uni@gmail.com', '095558888', '0116677889');

INSERT INTO supplieraddress (suppid, addr1, city, postcode, state) VALUES
(300001, 'Lot 22 Jalan Kenanga', 'Kuala Terengganu', '21000', 'Terengganu'),
(300002, 'No 8 Jalan Sultan', 'Kuantan', '25000', 'Pahang'),
(300003, '45 Jalan Aman', 'Johor Bahru', '81100', 'Johor'),
(300004, '12 Jalan Tok Janggut', 'Kota Bharu', '15000', 'Kelantan'),
(300005, '3 Lorong Mawar', 'Alor Setar', '05000', 'Terengganu');

INSERT INTO Item(itmcode,	itmdesc,iccode,avgmthlyusage,reorderlevel,reorderqty)
VALUES
('G001', 'Gas Cooker', 101, 20.00, 5.00, 10.00),
('G002', 'Grill Oven', 101, 15.00, 3.00, 8.00),
('E001', 'Electric Kettle', 102, 18.00, 4.00, 12.00),
('E002', 'Earphone', 102, 50.00, 10.00, 50.00),
('F001', 'Folding Table', 103, 8.00, 2.00, 5.00),
('F002', 'Fiber Chair', 103, 10.00, 3.00, 7.00),
('S001', 'Shampoo Bottle', 104, 60.00, 15.00, 30.00),
('S002', 'Sugar Pack', 104, 100.00, 20.00, 50.00),
('T001', 'Textbook A', 105, 25.00, 5.00, 15.00),
('T002', 'Pen Blue', 105, 80.00, 30.00, 50.00);

INSERT INTO itemsupplier(itmcode,suppid,totqtysupptodate,firstdatesupply,lastdatesupply,
stdprice,discount,minorderqty, maxorderqty) 
VALUES 
('G001', 300001, 200.00, '2024-01-10', '2024-11-01', 120.00, 5.00, 10.00, 50.00),
('G002', 300002, 150.00, '2024-02-12', '2024-10-28', 180.00, 10.00, 8.00, 40.00),
('E001', 300003, 300.00, '2024-03-01', '2024-10-20', 80.00, 2.00, 20.00, 100.00),
('E002', 300004, 500.00, '2024-01-25', '2024-10-30', 25.00, 1.00, 50.00, 200.00),
('F001', 300005, 90.00, '2024-02-20', '2024-11-02', 150.00, 5.00, 2.00, 20.00),
('F002', 300001, 120.00, '2024-01-15', '2024-11-03', 60.00, 3.00, 5.00, 25.00),
('S001', 300002, 400.00, '2024-04-10', '2024-11-05', 12.00, 1.00, 30.00, 150.00),
('S002', 300003, 800.00, '2024-05-01', '2024-11-07', 3.00, 0.50, 40.00, 200.00),
('T001', 300004, 120.00, '2024-03-25', '2024-11-08', 50.00, 2.00, 10.00, 60.00),
('T002', 300005, 600.00, '2024-04-15', '2024-11-10', 1.50, 0.20, 20.00, 300.00);

INSERT INTO itemstock VALUES
('G001', '2024-11-01', 40.00, 'Opened'),
('G002', '2024-10-28', 25.00, 'Opened'),
('E001', '2024-10-20', 55.00, 'Opened'),
('E002', '2024-10-30', 200.00, 'Closed'),
('F001', '2024-11-02', 15.00, 'Opened'),
('F002', '2024-11-03', 22.00, 'Closed'),
('S001', '2024-11-05', 70.00, 'Opened'),
('S002', '2024-11-07', 150.00, 'Opened'),
('T001', '2024-11-08', 30.00, 'Closed'),
('T002', '2024-11-10', 80.00, 'Opened');

SELECT i.itmcode,i.itmdesc,s.stkcountdate,s.qtystock FROM  item i -- no 1
JOIN itemstock s ON i.itmcode = s.itmcode
WHERE i.itmcode LIKE 'G%';

SELECT s.suppname,sp.addr1,sp.city,sp.postcode,sp.state FROM -- no 2
Supplier s 
JOIN supplieraddress sp ON s.suppid=sp.suppid
WHERE s.suppid='300001';


SELECT c.iccode,c.icdescription,i.itmcode,i.itmdesc,i.reorderqty FROM  itemcategory c
LEFT JOIN Item i on c.iccode = i.iccode;SELECT s.suppid, s.suppname, i.itmcode, it.itmdesc, i.lastdatesupply -- no 3
FROM itemsupplier i
RIGHT JOIN item it ON i.itmcode = it.itmcode
LEFT JOIN supplier s ON s.suppid = i.suppid;

SELECT s.suppid, s.suppname, i.itmcode, it.itmdesc, i.lastdatesupply -- no 5
FROM itemsupplier i
JOIN supplier s USING (suppid)
JOIN item it USING (itmcode)
WHERE s.suppid = 300005;

SELECT  -- no 6
    i.itmcode AS ProductCode,
    i.itmdesc AS ProductName,
    s.qtystock AS StockOnHand
FROM Item i
JOIN itemcategory c ON i.iccode = c.iccode
JOIN itemstock s ON i.itmcode = s.itmcode
WHERE c.icdescription = 'Home Appliances';

SELECT sa.suppaddid, sa.suppid, sa.addr1, sa.state -- no7
FROM Supplieraddress sa
WHERE sa.state IN (
    SELECT state
    FROM Supplieraddress
    GROUP BY state
    HAVING COUNT(DISTINCT suppaddid) > 1
)
ORDER BY sa.state, sa.suppid;

